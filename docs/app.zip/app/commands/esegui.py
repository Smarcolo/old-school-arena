"""Esegue un Comando sulla partita e ritorna un messaggio in italiano per l'interfaccia."""
from app.commands.parser import Comando
import re

from app.engine import azioni, combattimento, mana, mulligan
from app.engine.abilita import analizza_abilita
from app.engine.stato import Partita
from app.engine.validazione import AzioneIllegale, max_bersagli
from app.engine.zone import Zona

COLORI_PAROLE = {"bianco": "W", "blu": "U", "nero": "B", "rosso": "R", "verde": "G", "incolore": "C"}
GIOCATORI_IO = {"me", "io", "me stesso", "tu"}
GIOCATORI_AVVERSARIO = {"avversaria", "avversario", "lei", "faccia", "lui"}


def trova_bersaglio(partita: Partita, giocatore: str, testo: str, esclusi: tuple[str, ...] = ()) -> str | None:
    """Da testo libero a riferimento: nome di un giocatore, «me»/«avversaria», nome o id di una creatura
    in campo (con più omonime preferisce quelle dell'avversario). `esclusi`: riferimenti già scelti (più bersagli)."""
    t = testo.strip().lower()
    if t in GIOCATORI_IO:
        return f"giocatore:{giocatore}"
    if t in GIOCATORI_AVVERSARIO:
        return f"giocatore:{partita.avversario_di(giocatore).nome}"
    for g in partita.giocatori:
        if g.nome.lower() == t:
            return f"giocatore:{g.nome}"
    ordine = [partita.avversario_di(giocatore), partita.giocatore(giocatore)]
    for g in ordine:
        for c in g[Zona.CAMPO]:
            if (c.id == t or c.nome.lower() == t) and f"carta:{c.id}" not in esclusi:
                return f"carta:{c.id}"
    # magie in pila (prima quelle dell'avversario, dalla cima), poi il tuo cimitero (Regrowth)
    for o in sorted(reversed(partita.pila), key=lambda o: o.controllore == giocatore):
        if o.id == t or o.carta.nome.lower() == t:
            return f"pila:{o.id}"
    for c in partita.giocatore(giocatore)[Zona.CIMITERO]:
        if c.id == t or c.nome.lower() == t:
            return f"cimitero:{c.id}"
    return None


AIUTO = ("Comandi: gioca <carta> (terre e magie), gioca <carta> [x=N] su <bersaglio>, scelgo <carta>, tappa <carta> [per <colore>], "
         "attiva <carta> [su <bersaglio>], passa, fine turno, "
         "tengo / mulligan / in fondo <carte>, concedo, danni [n] su <creatura> (banding), attacca con <carte>|tutto (con «+» in banda), non attacco, paga / non pago, blocca <attaccante> con <bloccante>; ..., nessun blocco, "
         "mano, mana, stato, pesca [n], vita <+/-n>, giudice <domanda>")
TUTTO = {"", "tutto", "tutte", "tutti", "con tutto", "con tutte"}


def _scegli(candidate, testo: str, gia_usate: set[str]):
    """Prima carta tra le candidate con quel nome o id, non ancora usata."""
    t = testo.strip().lower()
    return next((c for c in candidate if c.id not in gia_usate and (c.id == t or c.nome.lower() == t)), None)


def _dividi_danni(partita: Partita, giocatore: str, argomento: str) -> str:
    """«danni su orso» (tutti) oppure «danni 2 su orso, 1 su gigante»."""
    scelta = partita.scelta
    if scelta is None or scelta.tipo != "danni":
        return "Ora non c'è da dividere danni."
    candidate = scelta.dati["candidate"]
    ripartizione: dict[str, int] = {}
    for parte in re.split(r",|\s+e\s+", argomento):
        if not parte.strip():
            continue
        m = re.match(r"^\s*(?:(\d+)\s+)?su\s+(.+?)\s*$", parte)
        if not m:
            return "Scrivi «danni su <creatura>» oppure «danni 2 su <creatura>, 1 su <altra>»."
        nome = m.group(2).lower()
        id_ = next((i for i, n in candidate.items() if i == nome or n.lower() == nome and i not in ripartizione), None)
        if id_ is None:
            return f"«{m.group(2)}» non è tra le creature coinvolte ({', '.join(candidate.values())})."
        ripartizione[id_] = int(m.group(1)) if m.group(1) else scelta.dati["danni"] - sum(ripartizione.values())
    combattimento.assegna_danni(partita, giocatore, ripartizione)
    return "Danni divisi."


def _attacca(partita: Partita, giocatore: str, argomento: str) -> str:
    """«attacca con a, b e c»; con «+» si forma una banda: «attacca con benalish hero + grizzly bears, hill giant»."""
    possibili = combattimento.possibili_attaccanti(partita, giocatore)
    bande = []
    if argomento.strip() in TUTTO:
        scelti = possibili
    else:
        scelti, usati = [], set()
        for gruppo in re.split(r",|\s+e\s+", argomento):
            membri = []
            for nome in gruppo.split("+"):
                if not nome.strip():
                    continue
                c = _scegli(possibili, nome, usati)
                if c is None:
                    return f"«{nome.strip()}» non può attaccare."
                membri.append(c)
                usati.add(c.id)
            scelti += membri
            if len(membri) > 1:
                bande.append(membri)
    combattimento.dichiara_attaccanti(partita, giocatore, scelti, bande)
    testo = "Attacchi con " + (", ".join(c.nome for c in scelti) or "nessuna creatura") + "."
    for banda in bande:
        testo += " In banda: " + " + ".join(c.nome for c in banda) + "."
    return testo


def _blocca(partita: Partita, giocatore: str, argomento: str) -> str:
    attaccanti = combattimento.attaccanti_in_campo(partita)
    possibili = combattimento.possibili_bloccanti(partita, giocatore)
    coppie, usati = [], set()
    for parte in re.split(r";|\s+poi\s+", argomento):
        if not parte.strip():
            continue
        if " con " not in parte:
            return "Scrivi «blocca <attaccante> con <tua creatura>»."
        nome_att, nome_blocc = parte.split(" con ", 1)
        attaccante = _scegli(attaccanti, nome_att, set())
        if attaccante is None:
            return f"«{nome_att.strip()}» non sta attaccando."
        bloccante = _scegli(possibili, nome_blocc, usati)
        if bloccante is None:
            return f"«{nome_blocc.strip()}» non può bloccare."
        coppie.append((bloccante, attaccante))
        usati.add(bloccante.id)
    combattimento.dichiara_bloccanti(partita, giocatore, coppie)
    return "Blocchi: " + "; ".join(f"{b.nome} blocca {a.nome}" for b, a in coppie) + "."


def esegui(partita: Partita, giocatore: str, cmd: Comando, giudice=None) -> str:
    try:
        match cmd.azione:
            case "aiuto":
                return AIUTO
            case "mano":
                mano = partita.giocatore(giocatore)[Zona.MANO]
                return "Mano: " + (", ".join(f"{c.nome} {c.costo}".strip() for c in mano) or "vuota")
            case "mana":
                return "Riserva di mana: " + mana.formatta(partita.giocatore(giocatore).riserva)
            case "stato":
                return " | ".join(f"{g.nome}: {g.vita} vita, {len(g[Zona.MANO])} in mano, "
                                  f"{len(g[Zona.GRIMORIO])} nel grimorio" for g in partita.giocatori)
            case "pesca" | "vita" if partita.vincitore or mulligan.in_corso(partita):
                return "Ora no: la partita è finita o il mulligan è in corso."
            case "pesca":
                carte = azioni.pesca(partita, giocatore, cmd.numero or 1)
                azioni.azioni_di_stato(partita)
                return "Hai pescato: " + ", ".join(c.nome for c in carte)
            case "gioca" | "lancia":
                carta = azioni.trova_in_zona(partita, giocatore, Zona.MANO, cmd.argomento)
                if carta is None:
                    return f"Non hai «{cmd.argomento}» in mano."
                if carta.is_terra:
                    azioni.gioca_terra(partita, giocatore, carta)
                    return f"Hai giocato {carta.nome}."
                bersagli = []
                if cmd.bersaglio:
                    # più bersagli (Fireball): «su avversaria e orso», «su a, b e c»
                    testi = re.split(r"\s*,\s*|\s+e\s+", cmd.bersaglio) if max_bersagli(carta) != 1 else [cmd.bersaglio]
                    for testo in testi:
                        rif = trova_bersaglio(partita, giocatore, testo, tuple(bersagli))
                        if rif is None:
                            return f"Non trovo il bersaglio «{testo}»."
                        bersagli.append(rif)
                azioni.lancia(partita, giocatore, carta, bersagli, cmd.x)
                return f"Hai lanciato {carta.nome}: è in pila. Scrivi «passa» per farla risolvere."
            case "attiva":
                nome, indice = cmd.argomento, 0
                if m := re.match(r"^(.+?)\s+(\d)$", nome):
                    nome, indice = m.group(1), int(m.group(2)) - 1
                carta = azioni.trova_in_zona(partita, giocatore, Zona.CAMPO, nome)
                if carta is None:
                    return f"Non hai «{nome}» sul campo."
                abilita = analizza_abilita(carta)
                if not abilita:
                    return f"{carta.nome} non ha abilità attivabili che il motore conosca."
                if indice >= len(abilita):
                    return f"{carta.nome} ha solo {len(abilita)} abilità."
                bersagli = []
                if cmd.bersaglio:
                    rif = trova_bersaglio(partita, giocatore, cmd.bersaglio)
                    if rif is None:
                        return f"Non trovo il bersaglio «{cmd.bersaglio}»."
                    bersagli = [rif]
                sacrificio = None
                if cmd.bersaglio and abilita[indice].sacrifica_tipo and not abilita[indice].bersaglio:
                    sacrificio = azioni.trova_in_zona(partita, giocatore, Zona.CAMPO, cmd.bersaglio)
                    bersagli = []
                azioni.attiva(partita, giocatore, carta, abilita[indice], bersagli, sacrificio)
                return f"Hai attivato l'abilità di {carta.nome}: è in pila."
            case "tappa":
                nome, colore = cmd.argomento, None
                if m := re.match(r"^(.+?)\s+per\s+\{?([wubrgc]|bianco|blu|nero|rosso|verde|incolore)\}?$", nome):
                    nome, colore = m.group(1), COLORI_PAROLE.get(m.group(2), m.group(2).upper())
                carta = azioni.trova_in_zona(partita, giocatore, Zona.CAMPO, nome)
                if carta is None:
                    return f"Non hai «{nome}» sul campo."
                azioni.tappa(partita, giocatore, carta, colore)
                return f"Hai tappato {carta.nome}. Riserva: {mana.formatta(partita.giocatore(giocatore).riserva)}"
            case "vita":
                azioni.modifica_vita(partita, giocatore, cmd.numero, "(manuale)")
                azioni.azioni_di_stato(partita)
                return f"Vita: {partita.giocatore(giocatore).vita}"
            case "attacca":
                return _attacca(partita, giocatore, cmd.argomento)
            case "nonattacco":
                combattimento.dichiara_attaccanti(partita, giocatore, [])
                return "Non attacchi."
            case "blocca":
                return _blocca(partita, giocatore, cmd.argomento)
            case "nonblocco":
                combattimento.dichiara_bloccanti(partita, giocatore, [])
                return "Non blocchi."
            case "concedo":
                if partita.vincitore:
                    return "La partita è già finita."
                azioni.concedi(partita, giocatore)
                return "Hai concesso la partita."
            case "tengo":
                mulligan.tieni(partita, giocatore)
                da_mettere = partita.mulligan[giocatore].da_mettere_in_fondo
                parola = "carta" if da_mettere == 1 else "carte"
                return f"Tieni la mano. Ora metti in fondo {da_mettere} {parola}." if da_mettere else "Tieni la mano."
            case "mulligan":
                mulligan.fai_mulligan(partita, giocatore)
                return "Mulligan: nuova mano di 7 carte."
            case "infondo":
                mano = partita.giocatore(giocatore)[Zona.MANO]
                scelte, usate = [], set()
                for nome in re.split(r",|\s+e\s+", cmd.argomento):
                    if not nome.strip():
                        continue
                    c = _scegli(mano, nome, usate)
                    if c is None:
                        return f"Non hai «{nome.strip()}» in mano."
                    scelte.append(c)
                    usate.add(c.id)
                mulligan.metti_in_fondo(partita, giocatore, scelte)
                return "Carte messe in fondo al mazzo."
            case "scelgo":
                scelta = partita.scelta
                if scelta is None or scelta.tipo not in ("cerca", "scegli"):
                    return "Ora non c'è da scegliere una carta."
                t = cmd.argomento.strip().lower()
                id_ = next((i for i, n in scelta.dati["carte"].items() if i == t or n.lower() == t), None)
                if id_ is None:
                    return f"«{cmd.argomento}» non è tra le carte che puoi scegliere."
                if scelta.tipo == "cerca":
                    azioni.rispondi_cerca(partita, giocatore, id_)
                    return "Carta presa e grimorio rimescolato."
                azioni.rispondi_scegli(partita, giocatore, id_)
                return "Fatto."
            case "danni":
                return _dividi_danni(partita, giocatore, cmd.argomento)
            case "paga" | "nonpago":
                azioni.rispondi_scelta(partita, giocatore, cmd.azione == "paga")
                return "Hai pagato." if cmd.azione == "paga" else "Non hai pagato."
            case "passa":
                if combattimento.deve_dichiarare_bloccanti(partita, giocatore):
                    combattimento.dichiara_bloccanti(partita, giocatore, [])
                    return "Non blocchi."
                azioni.passa_priorita(partita, giocatore)
                return "Passi."
            case "giudice":
                if giudice is None:
                    return "Il giudice non è disponibile."
                return giudice.rispondi(cmd.argomento)["risposta"]
            case _:
                return f"Non ho capito «{cmd.argomento}». {AIUTO}"
    except AzioneIllegale as e:
        return f"Mossa non valida: {e}."
