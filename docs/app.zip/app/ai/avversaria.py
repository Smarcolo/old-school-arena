"""Avversaria AI. Fa una sola azione per chiamata e viene richiamata finché ha la priorità.

Priorità delle scelte:
0. In combattimento: dichiara attaccanti e bloccanti quando tocca a lei.
1. Rigenerazione o Giant Growth per salvare una sua creatura (da un danno in pila o in combattimento);
   Giant Growth anche per chiudere la partita.
2. Lightning Bolt o un'abilità di danno su una creatura avversaria che muore (anche in risposta).
3. Nel suo turno, fase principale, pila vuota: terra, poi la creatura più cara che può pagare.
4. Sempre nella sua fase principale: Lightning Bolt all'avversario se non ci sono creature da uccidere.
5. Dopo i blocchi: pompa gli attaccanti non bloccati (es. firebreathing) con il mana che ha.
6. Nella fase finale dell'avversario: abilità di danno a {T} rimaste stappate sull'avversario.
7. Altrimenti passa.
"""
from app.ai import politiche, previsione
from app.engine import azioni, combattimento, mana
from app.engine.abilita import analizza_abilita
from app.engine.inneschi import analizza_inneschi
from app.engine.stato import Carta, Fase, Partita
from app.engine.validazione import FASI_PRINCIPALI, puo_attivare, puo_giocare_terra, puo_lanciare
from app.engine.zone import Zona

DANNI_BOLT = 3


def _danni_oggetto(oggetto) -> int:
    """Danni che un oggetto in pila infliggerà al suo bersaglio (0 se non è un danno noto)."""
    if oggetto.abilita:
        return oggetto.abilita.danni if oggetto.abilita.tipo == "danno" else 0
    return DANNI_BOLT if oggetto.carta.nome == "Lightning Bolt" else 0


def _danni_in_arrivo(partita: Partita, nome: str, creatura: Carta) -> int:
    """Danni che le magie e abilità dell'AI già in pila stanno per infliggere a quella creatura."""
    return sum(_danni_oggetto(o) for o in partita.pila
               if o.controllore == nome and o.bersagli == [f"carta:{creatura.id}"])


def _vita(c: Carta) -> int:
    return c.costituzione_attuale - c.danni


def _danni_in_combattimento(partita: Partita, c: Carta) -> int:
    """Stima dei danni che c subirà in combattimento."""
    comb = partita.combattimento
    if c.id in comb.blocchi:
        return sum(t[1].forza_attuale for i in comb.blocchi[c.id]
                   if (t := partita.trova_in_campo(i)) and not c.protetta_da(t[1]))
    for attaccante, bloccanti in comb.blocchi.items():
        if c.id in bloccanti and (t := partita.trova_in_campo(attaccante)) and not c.protetta_da(t[1]):
            return t[1].forza_attuale
    return 0


def _rigenerazione_pronta(partita: Partita, nome: str, c: Carta):
    """L'abilità di rigenerazione di c, se si può attivare adesso."""
    return next((ab for ab in analizza_abilita(c) if ab.tipo == "rigenera"
                 and puo_attivare(partita, nome, c, ab) is None), None)


def _potra_rigenerare(partita: Partita, nome: str, c: Carta) -> bool:
    """Per valutare i blocchi: c ha la rigenerazione e il mana per pagarla (si attiverà dopo la dichiarazione)."""
    from app.engine.validazione import fonti_di_mana
    for ab in analizza_abilita(c):
        if ab.tipo == "rigenera":
            fonti = fonti_di_mana(partita, nome, c)
            if mana.piano_pagamento(partita.giocatore(nome).riserva, fonti, mana.analizza_costo(ab.costo_mana)) is not None:
                return True
    return False


def da_rigenerare(partita: Partita, nome: str) -> tuple[Carta, object] | None:
    """Una creatura dell'AI senza scudo che sta per morire (danno in cima alla pila o combattimento) e può rigenerare."""
    minacciate: list[Carta] = []
    if partita.pila:
        cima = partita.pila[-1]
        if cima.controllore != nome and cima.bersagli:
            bersaglio = partita.risolvi_bersaglio(cima.bersagli[0])
            if isinstance(bersaglio, Carta) and _vita(bersaglio) <= _danni_oggetto(cima):
                minacciate.append(bersaglio)
    else:
        comb = partita.combattimento
        if comb and comb.bloccanti_dichiarati and not comb.danni_inflitti:
            in_combattimento = set(comb.attaccanti) | comb.bloccanti()
            minacciate = [c for c in partita.giocatore(nome)[Zona.CAMPO]
                          if c.id in in_combattimento and _vita(c) <= _danni_in_combattimento(partita, c)]
    for c in minacciate:
        if c in partita.giocatore(nome)[Zona.CAMPO] and not c.scudi_rigenerazione and not c.disintegrata:
            if ab := _rigenerazione_pronta(partita, nome, c):
                return c, ab
    return None


def bersaglio_growth(partita: Partita, nome: str, growth: Carta | None = None) -> Carta | None:
    """Creatura dell'AI da salvare (o con cui chiudere la partita) con +3/+3, se c'è."""
    mie = [c for c in partita.giocatore(nome)[Zona.CAMPO] if c.is_creatura and not c.protetta_da(growth)]
    if partita.pila:
        cima = partita.pila[-1]
        if cima.controllore != nome and cima.bersagli:
            bersaglio = partita.risolvi_bersaglio(cima.bersagli[0])
            danni = _danni_oggetto(cima)
            if bersaglio in mie and _vita(bersaglio) <= danni < _vita(bersaglio) + 3:
                return bersaglio
        return None
    comb = partita.combattimento
    if not comb or not comb.bloccanti_dichiarati or comb.danni_inflitti:
        return None
    in_combattimento = set(comb.attaccanti) | comb.bloccanti()
    for c in mie:
        if c.id in in_combattimento and _vita(c) <= _danni_in_combattimento(partita, c) < _vita(c) + 3:
            return c
    if partita.giocatore_attivo.nome == nome:
        avversario = partita.avversario_di(nome)
        liberi = [t[1] for i in comb.attaccanti if i not in comb.blocchi and (t := partita.trova_in_campo(i))]
        if liberi and sum(c.forza_attuale for c in liberi) < avversario.vita <= sum(c.forza_attuale for c in liberi) + 3:
            return liberi[0]
    return None


def bersaglio_bolt(partita: Partita, nome: str, bolt: Carta | None = None) -> str | None:
    avversario = partita.avversario_di(nome)
    bolt_in_mano = sum(1 for c in partita.giocatore(nome)[Zona.MANO] if c.nome == "Lightning Bolt")
    if avversario.vita <= DANNI_BOLT * bolt_in_mano:
        return f"giocatore:{avversario.nome}"
    if migliore := _creatura_uccidibile(partita, nome, DANNI_BOLT, bolt):
        return f"carta:{migliore.id}"
    if (not partita.pila and partita.giocatore_attivo.nome == nome and partita.fase in FASI_PRINCIPALI
            and (avversario.vita <= 10 or len(partita.giocatore(nome)[Zona.MANO]) >= 6)):
        # in faccia solo verso la fine (o con la mano piena): prima conviene tenerlo per le creature
        return f"giocatore:{avversario.nome}"
    return None


def bersaglio_aura(partita: Partita, nome: str, aura: Carta) -> Carta | None:
    """Le aure gestite sono tutte di potenziamento: vanno sulla propria creatura più forte che possono incantare."""
    candidate = [c for c in partita.giocatore(nome)[Zona.CAMPO] if c.is_creatura and not c.protetta_da(aura)]
    return max(candidate, key=lambda c: (c.forza_attuale, c.costituzione_attuale)) if candidate else None


CONTROMAGIE = ("Counterspell", "Mana Drain")


def lascia_contromagia(partita: Partita, nome: str, carta: Carta) -> bool:
    """Con una contromagia in mano (e l'avversario con carte in mano) non spende il mana che serve a lanciarla."""
    g = partita.giocatore(nome)
    if not any(c.nome in CONTROMAGIE for c in g[Zona.MANO]) or len(partita.avversario_di(nome)[Zona.MANO]) < 2:
        return True
    if len(g[Zona.MANO]) > 7:  # altrimenti a fine turno scarterebbe: meglio giocare le carte
        return True
    from app.engine.validazione import fonti_di_mana
    costo = mana.con_x(mana.analizza_costo(carta.costo), 0)
    costo["U"] = costo.get("U", 0) + 2
    return mana.piano_pagamento(g.riserva, fonti_di_mana(partita, nome), costo) is not None


def _forza_terrestre(partita: Partita, chi: str) -> int:
    return sum(c.forza_attuale for c in partita.giocatore(chi)[Zona.CAMPO] if c.is_creatura and not c.ha("flying"))


def permanente_utile(partita: Partita, nome: str, carta: Carta) -> bool:
    """Gli incantesimi simmetrici solo quando fanno più male all'avversario."""
    avversario = partita.avversario_di(nome).nome
    if "Creatures without flying can't attack." in carta.testo:  # Moat
        return _forza_terrestre(partita, nome) < _forza_terrestre(partita, avversario)
    if carta.nome == "The Abyss":
        def quante(chi):
            return sum(1 for c in partita.giocatore(chi)[Zona.CAMPO] if c.is_creatura and "Artifact" not in c.tipo_attuale)
        return quante(nome) < quante(avversario)
    return True


def factory_da_animare(partita: Partita, nome: str, per_attaccare: bool):
    """Mishra's Factory (e simili): animata nella prima fase principale se può attaccare senza farsi uccidere,
    oppure nel combattimento avversario (dopo gli attacchi, prima dei blocchi) se può bloccare bene."""
    comb = partita.combattimento
    avversario = partita.avversario_di(nome).nome
    if not per_attaccare and not (comb and comb.attaccanti_dichiarati and not comb.bloccanti_dichiarati
                                  and partita.giocatore_attivo.nome == avversario and not partita.pila):
        return None
    for c in partita.giocatore(nome)[Zona.CAMPO]:
        if c.animata or c.tappata or partita.ha_debolezza_da_evocazione(c) or c.entrata_nel_turno == partita.turno:
            continue
        for ab in analizza_abilita(c):
            if ab.tipo != "anima" or puo_attivare(partita, nome, c, ab) is not None:
                continue
            f, cos = ab.forza, ab.costituzione
            if per_attaccare:
                bloccanti = combattimento.possibili_bloccanti(partita, avversario)
                if not any(b.forza_attuale >= cos and f < b.costituzione_attuale - b.danni for b in bloccanti):
                    return c, ab
            else:
                attaccanti = combattimento.attaccanti_in_campo(partita)
                in_arrivo = sum(x.forza_attuale for x in attaccanti)
                buono = any(x.forza_attuale < cos and x.costituzione_attuale - x.danni <= f and not x.ha("flying")
                            for x in attaccanti)
                if buono or in_arrivo >= partita.giocatore(nome).vita:
                    return c, ab
    return None


def decidi_mulligan(partita: Partita, nome: str) -> None:
    """Tiene con 2-5 terre su 7 (o dopo due mulligan); poi mette in fondo le carte che servono di meno."""
    from app.engine import mulligan
    stato = partita.mulligan[nome]
    mano = partita.giocatore(nome)[Zona.MANO]
    if not stato.tenuta:
        terre = sum(c.is_terra for c in mano)
        if 2 <= terre <= 5 or stato.fatti >= 2:
            mulligan.tieni(partita, nome)
        else:
            mulligan.fai_mulligan(partita, nome)
        return
    terre = [c for c in mano if c.is_terra]
    magie = sorted((c for c in mano if not c.is_terra), key=lambda c: -sum(mana.analizza_costo(c.costo).values()))
    via = []
    for _ in range(stato.da_mettere_in_fondo):
        # troppe terre rispetto alle magie: via una terra, altrimenti la magia più cara
        if terre and (len(terre) > len(magie) or not magie):
            via.append(terre.pop())
        else:
            via.append(magie.pop(0))
    mulligan.metti_in_fondo(partita, nome, via)


def scelta_automatica(partita: Partita, nome: str, azione: str, candidate: list[Carta]) -> Carta:
    """Scelte tra carte fatte dall'AI: sacrifica/scarta la meno preziosa; con Erhnam Djinn dà passa-foreste alla
    creatura avversaria più debole."""
    from app.engine.carte_implementate import valore_carta
    if azione == "passaforeste":
        return min(candidate, key=lambda c: (c.forza_attuale, c.costituzione_attuale))
    if azione == "riprendi":  # Recall: la migliore dal cimitero
        return max(candidate, key=valore_carta)
    return min(candidate, key=valore_carta)


def decidi_scelta(partita: Partita, nome: str) -> None:
    """«Paga o subisci»: paga se può. (Le divisioni del banding l'AI le fa in automatico, senza Scelta.)"""
    if partita.scelta.tipo in ("scegli", "cerca"):
        candidate = [c for g in partita.giocatori for z in (Zona.CAMPO, Zona.MANO, Zona.GRIMORIO, Zona.CIMITERO)
                     for c in g[z] if c.id in partita.scelta.dati["carte"]]
        if partita.scelta.tipo == "cerca":
            from app.engine.carte_implementate import scegli_migliore
            azioni.rispondi_cerca(partita, nome, scegli_migliore(candidate).id)
        else:
            azioni.rispondi_scegli(partita, nome, scelta_automatica(partita, nome, partita.scelta.dati["azione"], candidate).id)
        return
    if partita.scelta.tipo == "danni":
        from app.engine.combattimento import _assorbitore
        dati = partita.scelta.dati
        candidate = [t[1] for i in dati["candidate"] if (t := partita.trova_in_campo(i))]
        fonte = partita.trova_in_campo(dati["fonte"])[1]
        combattimento.assegna_danni(partita, nome, {_assorbitore(fonte, candidate).id: dati["danni"]})
        return
    azioni.rispondi_scelta(partita, nome, azioni.puo_pagare_scelta(partita))


def _muore_a_fine_turno(c: Carta) -> bool:
    return any(i.momento == "finale" and i.effetto == "sacrifica" for i in analizza_inneschi(c))


def _turni_per_uccidere(vita: int, forza: int) -> float:
    return vita / forza if forza > 0 else float("inf")


def _danni_del_contrattacco(partita: Partita, nome: str, a_casa: list[Carta]) -> int:
    """Danni che l'avversario farebbe attaccando con tutto al prossimo turno, se lei blocca con le creature
    rimaste a casa (ognuna ferma l'attaccante più forte che può bloccare)."""
    avversario = partita.avversario_di(nome)
    attaccanti = sorted((c for c in avversario[Zona.CAMPO] if c.is_creatura and not c.ha("defender")
                         and "Wall" not in c.tipo_attuale), key=lambda c: -c.forza_attuale)
    liberi = list(a_casa)
    passano = 0
    for a in attaccanti:
        b = next((b for b in liberi if not a.ha("flying") or b.ha("flying") or b.ha("reach")), None)
        if b is None:
            passano += a.forza_attuale
        else:
            liberi.remove(b)
    return passano


RISPOSTE_ALLA_FACTORY = {"Swords to Plowshares", "Disenchant", "Shatter", "Lightning Bolt"}


def bloccanti_nascosti(partita: Partita, chi: str) -> list[Carta]:
    """Le terre di `chi` che possono diventare bloccanti (Mishra's Factory): stappate, non animate, con un altro
    mana per pagare l'animazione. Rese come creature finte già pompate dalla loro abilità sugli Assembly-Worker
    (la Factory blocca e poi si tappa per darsi +1/+1): un giocatore esperto ne tiene conto prima di attaccare."""
    g = partita.giocatore(chi)
    terre_altrui = partita.avversario_di(chi)[Zona.CAMPO]
    finte = []
    for c in g[Zona.CAMPO]:
        if c.tappata or c.is_creatura:
            continue
        abilita = analizza_abilita(c)
        anima = next((ab for ab in abilita if ab.tipo == "anima"), None)
        if anima is None:
            continue
        costo = mana.analizza_costo(anima.costo_mana)
        # le sue fonti stappate (non serve che abbia la priorità adesso: conta cosa potrà fare quando attacco)
        fonti = [f for x in g[Zona.CAMPO] if x is not c and not x.tappata and not partita.ha_debolezza_da_evocazione(x)
                 and (f := mana.fonte_in_partita(x, terre_altrui))]
        if mana.piano_pagamento(g.riserva, fonti, costo) is None:
            continue
        pompa = next((ab for ab in abilita if ab.tipo == "pompa_bersaglio"), None)
        f, cos = anima.forza + (pompa.forza if pompa else 0), anima.costituzione + (pompa.costituzione if pompa else 0)
        finte.append(Carta(c.nome, anima.tipo_animato or "Artifact Creature", "", f, cos))
    return finte


def _ha_risposta_alla_factory(partita: Partita, nome: str) -> bool:
    """Swords, Disenchant, Shatter o Bolt lanciabili: se la Factory blocca, la si toglie di mezzo."""
    return any(c.nome in RISPOSTE_ALLA_FACTORY and puo_lanciare(partita, nome, c) is None
               for c in partita.giocatore(nome)[Zona.MANO])


def scegli_attaccanti(partita: Partita, nome: str) -> list[Carta]:
    """Attacca con ogni creatura che nessun bloccante possibile (anche una Mishra's Factory avversaria pronta ad
    animarsi, vedi bloccanti_nascosti) ucciderebbe senza morire a sua volta; se sta
    vincendo la corsa (uccide prima di essere uccisa) attacca anche quando il blocco peggiore è uno scambio alla pari.
    Tiene a casa i bloccanti che servono se il contrattacco avversario sarebbe letale.
    Chi verrà sacrificato a fine turno (es. Ball Lightning) attacca sempre; tutti attaccano se il danno è letale."""
    g = partita.giocatore(nome)
    avversario = partita.avversario_di(nome)
    difensori = combattimento.possibili_bloccanti(partita, avversario.nome)
    tutti = combattimento.possibili_attaccanti(partita, nome)
    # Mishra's Factory avversaria: può animarsi, bloccare e pomparsi, a meno di avere la risposta in mano
    nascosti = [] if _ha_risposta_alla_factory(partita, nome) else bloccanti_nascosti(partita, avversario.nome)
    # attacco con tutto se, anche bloccando i più forti, i danni che passano bastano
    forze = sorted((a.forza_attuale for a in tutti), reverse=True)
    if sum(forze[len(difensori) + len(nascosti):]) >= avversario.vita:
        return tutti
    mia_forza = sum(c.forza_attuale for c in g[Zona.CAMPO] if c.is_creatura)
    sua_forza = sum(c.forza_attuale for c in avversario[Zona.CAMPO] if c.is_creatura)
    in_vantaggio = _turni_per_uccidere(avversario.vita, mia_forza) <= _turni_per_uccidere(g.vita, sua_forza)
    scelti = []
    for a in tutti:
        possibili = [b for b in difensori if combattimento.puo_bloccare_contro(partita, avversario.nome, b, a) is None]
        possibili += [b for b in nascosti if not a.ha("flying") and not a.protetta_da(b)]
        uccidono = [b for b in possibili if b.forza_attuale >= a.costituzione_attuale - a.danni and not a.protetta_da(b)]
        cattivo_scambio = any(a.forza_attuale < b.costituzione_attuale - b.danni or b.protetta_da(a) for b in uccidono)
        if _muore_a_fine_turno(a) or not cattivo_scambio:
            scelti.append(a)
    # chi ha cautela non si tappa: resta un bloccante anche se attacca
    a_casa = lambda: [c for c in g[Zona.CAMPO] if c.is_creatura and not c.tappata
                      and (c not in scelti or c.ha("vigilance"))]
    while scelti and _danni_del_contrattacco(partita, nome, a_casa()) >= g.vita:
        candidati = [c for c in scelti if not _muore_a_fine_turno(c) and not c.ha("vigilance")]
        if not candidati:
            break
        scelti.remove(max(candidati, key=lambda c: (c.costituzione_attuale, c.forza_attuale)))
    return scelti


def scegli_bande(attaccanti: list[Carta]) -> list[list[Carta]]:
    """Tutte le creature con banding che attaccano vanno in banda con l'attaccante più forte senza banding,
    così proteggono lui dai blocchi (i danni dei bloccanti li divide l'AI)."""
    con_banding = [c for c in attaccanti if c.ha("banding")]
    senza = [c for c in attaccanti if not c.ha("banding")]
    if not con_banding or len(attaccanti) < 2:
        return []
    banda = con_banding + ([max(senza, key=lambda c: c.forza_attuale)] if senza else [])
    return [banda] if len(banda) > 1 else []


def scegli_bloccanti(partita: Partita, nome: str) -> list[tuple[Carta, Carta]]:
    """Per ogni attaccante (dal più forte): blocca uccidendolo e sopravvivendo, altrimenti sopravvivendo,
    altrimenti scambiando alla pari o in meglio. Se i danni in arrivo la ucciderebbero, blocca comunque
    con la creatura più piccola."""
    disponibili = combattimento.possibili_bloccanti(partita, nome)
    attaccanti = sorted(combattimento.attaccanti_in_campo(partita), key=lambda c: -c.forza_attuale)
    blocchi = []

    def vita(c):
        return c.costituzione_attuale - c.danni

    def legali(a):
        return [b for b in disponibili if combattimento.puo_bloccare_contro(partita, nome, b, a) is None]

    for a in attaccanti:
        uccide = [b for b in legali(a) if b.forza_attuale >= vita(a) and not a.protetta_da(b)]
        sopravvive = [b for b in legali(a)
                      if vita(b) > a.forza_attuale or b.protetta_da(a) or _potra_rigenerare(partita, nome, b)]
        scelta = (next((b for b in uccide if b in sopravvive), None)
                  or (min(sopravvive, key=lambda b: b.forza_attuale) if sopravvive else None)
                  or next((b for b in uccide if b.forza_attuale <= a.forza_attuale), None))
        if scelta:
            blocchi.append((scelta, a))
            disponibili.remove(scelta)
    bloccati = {a.id for _, a in blocchi}
    liberi = [a for a in attaccanti if a.id not in bloccati]
    if sum(a.forza_attuale for a in liberi) >= partita.giocatore(nome).vita:
        for a in liberi:
            if not legali(a):
                continue
            piccola = min(legali(a), key=lambda b: b.forza_attuale)
            blocchi.append((piccola, a))
            disponibili.remove(piccola)
    return blocchi


def _per_id(partita: Partita, ids) -> list[Carta]:
    return [t[1] for i in ids if (t := partita.trova_in_campo(i))]


def _attacco_con_previsione(partita: Partita, nome: str, scelti: list[Carta]) -> list[Carta]:
    """Confronta l'attacco delle regole con: tutti all'attacco, nessuno, solo chi nessuno può uccidere bloccando."""
    tutti = combattimento.possibili_attaccanti(partita, nome)
    avversario = partita.avversario_di(nome).nome
    difensori = combattimento.possibili_bloccanti(partita, avversario)
    sicuri = [a for a in tutti if not any(
        combattimento.puo_bloccare_contro(partita, avversario, b, a) is None
        and b.forza_attuale >= a.costituzione_attuale - a.danni and not a.protetta_da(b) for b in difensori)]
    opzioni = []
    for gruppo in (scelti, tutti, [], sicuri):
        ids = tuple(sorted(c.id for c in gruppo))
        if ids not in opzioni:
            opzioni.append(ids)

    def applica(copia: Partita, ids) -> None:
        attaccanti = _per_id(copia, ids)
        combattimento.dichiara_attaccanti(copia, nome, attaccanti, scegli_bande(attaccanti))
    return _per_id(partita, previsione.migliore(partita, nome, opzioni, applica))


def _blocchi_con_previsione(partita: Partita, nome: str, blocchi: list[tuple[Carta, Carta]]) -> list[tuple[Carta, Carta]]:
    """Confronta i blocchi delle regole con: nessun blocco, i blocchi più un blocco «di sacrificio» sull'attaccante
    libero più forte, uno scambio (bloccante che lo uccide anche morendo) e un blocco doppio che lo uccide."""
    opzioni = [tuple((b.id, a.id) for b, a in blocchi), ()]
    usati = {b.id for b, _ in blocchi}
    bloccati = {a.id for _, a in blocchi}
    liberi = sorted((a for a in combattimento.attaccanti_in_campo(partita) if a.id not in bloccati),
                    key=lambda a: -a.forza_attuale)
    disponibili = [b for b in combattimento.possibili_bloccanti(partita, nome) if b.id not in usati]
    for a in liberi[:1]:
        legali = [b for b in disponibili if combattimento.puo_bloccare_contro(partita, nome, b, a) is None]
        if legali:
            piccola = min(legali, key=lambda b: (b.forza_attuale, b.costituzione_attuale))
            opzioni.append(opzioni[0] + ((piccola.id, a.id),))
            vita_a = a.costituzione_attuale - a.danni
            uccidono = [b for b in legali if b.forza_attuale >= vita_a and not a.protetta_da(b)]
            if uccidono:
                scambio = min(uccidono, key=lambda b: (b.forza_attuale + b.costituzione_attuale))
                opzioni.append(opzioni[0] + ((scambio.id, a.id),))
            else:
                coppia = sorted((b for b in legali if not a.protetta_da(b)), key=lambda b: -b.forza_attuale)[:2]
                if len(coppia) == 2 and sum(b.forza_attuale for b in coppia) >= vita_a:
                    opzioni.append(opzioni[0] + tuple((b.id, a.id) for b in coppia))
    opzioni = list(dict.fromkeys(opzioni))

    def applica(copia: Partita, coppie) -> None:
        combattimento.dichiara_bloccanti(copia, nome, [(copia.trova_in_campo(b)[1], copia.trova_in_campo(a)[1])
                                                       for b, a in coppie])
    scelta = previsione.migliore(partita, nome, opzioni, applica)
    return [(partita.trova_in_campo(b)[1], partita.trova_in_campo(a)[1]) for b, a in scelta]


REGOLE = ("regole",)
PASSA = ("passa",)
MAX_GIOCATE = 7


def _momento_importante(partita: Partita, nome: str) -> bool:
    """Quando vale la pena pensare: sua fase principale a pila vuota, risposta a una magia avversaria,
    fase finale dell'avversario, attaccanti avversari appena dichiarati (prima dei blocchi), dopo i blocchi."""
    attivo = partita.giocatore_attivo.nome
    comb = partita.combattimento
    return ((attivo == nome and partita.fase in FASI_PRINCIPALI and not partita.pila)
            or (partita.pila and partita.pila[-1].controllore != nome)
            or (attivo != nome and partita.fase == Fase.FINALE and not partita.pila)
            or bool(comb and attivo != nome and comb.attaccanti_dichiarati and not comb.bloccanti_dichiarati
                    and comb.attaccanti and not partita.pila)
            or bool(comb and comb.bloccanti_dichiarati and not comb.danni_inflitti and not partita.pila))


def _bersagli_candidati(partita: Partita, nome: str, carta: Carta, tipo: str) -> list[str]:
    from app.engine.carte_implementate import valore_carta
    from app.engine.effetti import bersaglio_legale
    avversario = partita.avversario_di(nome)
    rif = [f"pila:{o.id}" for o in reversed(partita.pila) if o.controllore != nome]
    ordine = ((lambda c: politiche.punteggio_terra(partita, nome, c) if c.is_terra else -1) if tipo == "terra"
              else valore_carta)  # spaccaterre: Maze of Ith, ultime fonti di un colore, terre utili
    rif += [f"carta:{c.id}" for c in sorted(avversario[Zona.CAMPO], key=ordine, reverse=True)]
    rif.append(f"giocatore:{avversario.nome}")
    if tipo == "giocatore":  # pescate (Ancestral, Braingeyser): su di sé
        rif.append(f"giocatore:{nome}")
    if carta.nome == "Giant Growth":
        rif = [f"carta:{c.id}" for c in partita.giocatore(nome)[Zona.CAMPO] if c.is_creatura]
    return [r for r in rif if bersaglio_legale(partita, tipo, r, carta)][:3]


def giocate_possibili(partita: Partita, nome: str) -> list[tuple]:
    """Le giocate da confrontare: le regole, passare, ogni magia lanciabile adesso (con il bersaglio della sua
    politica e i bersagli più interessanti) e le abilità attivabili dei suoi permanenti."""
    from app.engine.effetti import EFFETTI
    giocate = [REGOLE, PASSA]
    for carta in partita.giocatore(nome)[Zona.MANO]:
        if carta.is_terra or puo_lanciare(partita, nome, carta) is not None:
            continue
        comb = partita.combattimento
        if carta.nome == "Giant Growth" and not (partita.pila or (comb and comb.bloccanti_dichiarati)):
            continue  # il pompaggio serve in combattimento o in risposta
        possibili = []
        if (politica := politiche.POLITICHE.get(carta.nome)) and (scelta := politica(partita, nome, carta)):
            possibili.append((list(scelta[0]), scelta[1]))
        effetto = EFFETTI.get(carta.nome)
        if carta.is_aura:
            if bersaglio := bersaglio_aura(partita, nome, carta):
                possibili.append(([f"carta:{bersaglio.id}"], 0))
        elif effetto and effetto.bersaglio:
            for rif in _bersagli_candidati(partita, nome, carta, effetto.bersaglio):
                possibili.append(([rif], max(politiche._x_massimo(partita, nome, carta, [rif]), 0)))
        else:
            possibili.append(([], max(politiche._x_massimo(partita, nome, carta, []), 0)))
        for bersagli, x in possibili:
            if "X" in carta.costo and x < 1:
                continue
            if puo_lanciare(partita, nome, carta, bersagli, x) is None:
                giocata = ("lancia", carta.id, tuple(bersagli), x)
                if giocata not in giocate:
                    giocate.append(giocata)
    for fonte in partita.giocatore(nome)[Zona.CAMPO]:  # abilità (non di mana, non di rigenerazione)
        for ab in analizza_abilita(fonte):
            if ab.tipo in ("rigenera", "mana") or puo_attivare(partita, nome, fonte, ab) is not None:
                continue
            for rif in (_bersagli_candidati(partita, nome, fonte, ab.bersaglio) if ab.bersaglio else [None]):
                bersagli = (rif,) if rif else ()
                if puo_attivare(partita, nome, fonte, ab, list(bersagli)) is None:
                    giocate.append(("attiva", fonte.id, ab.indice, bersagli))
    return giocate[:MAX_GIOCATE]


def _esegui(partita: Partita, nome: str, giocata: tuple) -> None:
    if giocata == REGOLE:
        agisci(partita, nome)
    elif giocata == PASSA:
        azioni.passa_priorita(partita, nome)
    elif giocata[0] == "attiva":
        _, id_carta, indice, bersagli = giocata
        fonte = partita.trova_in_campo(id_carta)[1]
        ab = next(a for a in analizza_abilita(fonte) if a.indice == indice)
        azioni.attiva(partita, nome, fonte, ab, list(bersagli))
    else:
        _, id_carta, bersagli, x = giocata
        carta = next(c for c in partita.giocatore(nome)[Zona.MANO] if c.id == id_carta)
        azioni.lancia(partita, nome, carta, list(bersagli), x)


def _giocata_con_previsione(partita: Partita, nome: str) -> tuple:
    giocate = giocate_possibili(partita, nome)
    if len(giocate) <= 2:  # niente da lanciare: decidono le regole
        return REGOLE
    return previsione.migliore(partita, nome, giocate, lambda copia, g: _esegui(copia, nome, g))


def _abilita_pronte(partita: Partita, nome: str, tipo: str) -> list[tuple[Carta, object]]:
    return [(c, ab) for c in partita.giocatore(nome)[Zona.CAMPO] for ab in analizza_abilita(c)
            if ab.tipo == tipo and puo_attivare(partita, nome, c, ab) is None]


def _creatura_uccidibile(partita: Partita, nome: str, danni: int, fonte: Carta | None = None) -> Carta | None:
    avversario = partita.avversario_di(nome)
    uccidibili = [c for c in avversario[Zona.CAMPO] if c.is_creatura and not c.protetta_da(fonte)
                  and 0 < _vita(c) - _danni_in_arrivo(partita, nome, c) <= danni]
    return max(uccidibili, key=lambda c: (c.forza_attuale, c.costituzione_attuale)) if uccidibili else None


def agisci(partita: Partita, nome: str) -> None:
    g = partita.giocatore(nome)
    mano = list(g[Zona.MANO])
    avversario = partita.avversario_di(nome).nome

    if combattimento.deve_dichiarare_bloccanti(partita, nome):
        blocchi = scegli_bloccanti(partita, nome)
        if previsione.attiva():
            blocchi = _blocchi_con_previsione(partita, nome, blocchi)
        combattimento.dichiara_bloccanti(partita, nome, blocchi)
        return
    if combattimento.deve_dichiarare_attaccanti(partita, nome):
        attaccanti = scegli_attaccanti(partita, nome)
        if previsione.attiva():
            attaccanti = _attacco_con_previsione(partita, nome, attaccanti)
        combattimento.dichiara_attaccanti(partita, nome, attaccanti, scegli_bande(attaccanti))
        return

    if salvabile := da_rigenerare(partita, nome):
        azioni.attiva(partita, nome, *salvabile)
        return

    growth = next((c for c in mano if c.nome == "Giant Growth" and puo_lanciare(partita, nome, c) is None), None)
    if growth and (da_salvare := bersaglio_growth(partita, nome, growth)):
        azioni.lancia(partita, nome, growth, [f"carta:{da_salvare.id}"])
        return

    for fonte, ab in _abilita_pronte(partita, nome, "danno"):
        if ab.bersaglio in ("qualsiasi", "creatura") and (vittima := _creatura_uccidibile(partita, nome, ab.danni, fonte)):
            azioni.attiva(partita, nome, fonte, ab, [f"carta:{vittima.id}"])
            return

    if partita.giocatore_attivo.nome == nome and not partita.pila and partita.fase in FASI_PRINCIPALI:
        # la terra prima di tutto: più mana per le magie del turno
        if terra := next((c for c in mano if puo_giocare_terra(partita, nome, c) is None), None):
            azioni.gioca_terra(partita, nome, terra)
            return

    if previsione.attiva() and _momento_importante(partita, nome):
        giocata = _giocata_con_previsione(partita, nome)
        if giocata != REGOLE:
            _esegui(partita, nome, giocata)
            return

    if scelta := politiche.scegli_magia(partita, nome):
        carta, bersagli, x = scelta
        azioni.lancia(partita, nome, carta, bersagli, x)
        return
    if scelta := politiche.scegli_abilita(partita, nome):
        fonte, ab, bersagli = scelta
        azioni.attiva(partita, nome, fonte, ab, bersagli)
        return

    bolt = next((c for c in mano if c.nome == "Lightning Bolt" and puo_lanciare(partita, nome, c) is None), None)
    if bolt:
        rif = bersaglio_bolt(partita, nome, bolt)
        if rif and rif.startswith("carta:"):
            azioni.lancia(partita, nome, bolt, [rif])
            return

    if partita.giocatore_attivo.nome == nome and not partita.pila:
        terra = next((c for c in mano if puo_giocare_terra(partita, nome, c) is None), None)
        if terra:
            azioni.gioca_terra(partita, nome, terra)
            return
        acceleratori = [c for c in mano if "Artifact" in c.tipo and not c.is_creatura and mana.mana_prodotto(c)
                        and puo_lanciare(partita, nome, c) is None]
        if acceleratori:  # Mox, Sol Ring, Black Lotus: subito, sono mana in più
            azioni.lancia(partita, nome, acceleratori[0])
            return
        lanciabili = [c for c in mano if c.is_creatura and puo_lanciare(partita, nome, c) is None
                      and lascia_contromagia(partita, nome, c)]
        if not lanciabili:  # poi le aure, sulla sua creatura migliore
            for aura in (c for c in mano if c.is_aura and puo_lanciare(partita, nome, c) is None):
                if bersaglio := bersaglio_aura(partita, nome, aura):
                    azioni.lancia(partita, nome, aura, [f"carta:{bersaglio.id}"])
                    return
        if not lanciabili:  # poi gli altri permanenti (artefatti, incantesimi globali)
            lanciabili = [c for c in mano if c.is_permanente and not c.is_terra and not c.is_aura
                          and puo_lanciare(partita, nome, c) is None and permanente_utile(partita, nome, c)
                          and lascia_contromagia(partita, nome, c)]
        if lanciabili:
            piu_cara = max(lanciabili, key=lambda c: sum(mana.analizza_costo(c.costo).values()))
            azioni.lancia(partita, nome, piu_cara)
            return
        if bolt and (rif := bersaglio_bolt(partita, nome, bolt)):
            azioni.lancia(partita, nome, bolt, [rif])
            return
        if partita.fase == Fase.PRINCIPALE_1 and (factory := factory_da_animare(partita, nome, per_attaccare=True)):
            azioni.attiva(partita, nome, *factory)
            return

    if factory := factory_da_animare(partita, nome, per_attaccare=False):
        azioni.attiva(partita, nome, *factory)
        return

    comb = partita.combattimento
    solo_miei_pompaggi = all(o.controllore == nome and o.abilita and o.abilita.tipo == "pompa" for o in partita.pila)
    if (comb and comb.bloccanti_dichiarati and not comb.danni_inflitti and solo_miei_pompaggi
            and partita.giocatore_attivo.nome == nome):
        for fonte, ab in _abilita_pronte(partita, nome, "pompa"):
            creatura = azioni.creatura_pompata(partita, fonte, ab)
            if (creatura and creatura.id in comb.attaccanti and creatura.id not in comb.blocchi and ab.forza > 0
                    and not ab.sacrifica_tipo):
                azioni.attiva(partita, nome, fonte, ab)
                return

    if not partita.pila and partita.fase == Fase.FINALE and partita.giocatore_attivo.nome == avversario:
        for fonte, ab in _abilita_pronte(partita, nome, "danno"):
            if ab.tappa and ab.bersaglio in ("qualsiasi", "giocatore"):
                azioni.attiva(partita, nome, fonte, ab, [f"giocatore:{avversario}"])
                return

    azioni.passa_priorita(partita, nome)
